using UnityEngine;

[RequireComponent(typeof(PlayerController))]
public class PlayerStateMachine : MonoBehaviour
{
    public enum Locomotion { Idle, Walk, Run }

    public PlayerState currentState { get; private set; }

    private PlayerController pc;

    private PlayerIdle idle;
    private PlayerWalk walk;
    private PlayerRun run;
    private PlayerAir air;

    private void Awake()
    {
        pc = GetComponent<PlayerController>();

        idle = new PlayerIdle(this, pc);
        walk = new PlayerWalk(this, pc);
        run = new PlayerRun(this, pc);
        air = new PlayerAir(this, pc);
    }

    private void Start()
    {
        ChangeLocomotion(Locomotion.Idle);
    }

    public void ChangeLocomotion(Locomotion next)
    {
        switch (next)
        {
            case Locomotion.Idle: ChangeState(idle); break;
            case Locomotion.Walk: ChangeState(walk); break;
            case Locomotion.Run: ChangeState(run); break;
        }
    }

    private void ChangeState(PlayerState newState)
    {
        if (currentState == newState) return;
        Debug.Log($"FSM ChangeState: {currentState?.GetType().Name} -> {newState?.GetType().Name}");
        currentState?.Exit();
        currentState = newState;
        currentState.Enter();
    }

    private void Update()
    {
        currentState?.Update();
    }

    public void EnterAir()
    {
        ChangeState(air);
    }
}
