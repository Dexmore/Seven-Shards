using UnityEngine;
 class PlayerRun : PlayerState
{
    public PlayerRun(PlayerStateMachine fsm, PlayerController controller) : base(fsm, controller) { }

    public override void Enter()
    {
        controller.motor.SetSpeed(controller.motor.runSpeed);
    }

    public override void Update()
    {
        if (controller.ConsumeJump() && controller.motor.IsGrounded)
        {
            fsm.EnterAir();
            return;
        }

        if (!controller.HasMoveInput)
        {
            controller.motor.StopMove();
            fsm.ChangeLocomotion(PlayerStateMachine.Locomotion.Idle);
            return;
        }

        controller.motor.SetMoveInput(controller.GetCameraRelativeMoveDir());
        controller.playerAnim.SetSpeed01(controller.motor.GetSpeed01());

        if (!controller.IsRunHeld)
            fsm.ChangeLocomotion(PlayerStateMachine.Locomotion.Walk);
    }


    public override void Exit() { }
}
