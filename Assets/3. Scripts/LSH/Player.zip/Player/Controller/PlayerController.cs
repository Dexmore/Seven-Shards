﻿using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public PlayerMotor motor { get; private set; }
    public PlayerAnimation playerAnim { get; private set; }

    public Vector2 MoveInput { get; private set; }
    public bool HasMoveInput => MoveInput.sqrMagnitude > 0.01f;
    public bool IsRunHeld { get; private set; }
    public bool IsJumpPressed { get; private set; }
    private bool _jumpQueued;
    private InputSystem_Actions input;

    void Awake()
    {
        motor = GetComponent<PlayerMotor>();
        playerAnim = GetComponent<PlayerAnimation>();
        input = new InputSystem_Actions();
    }

    void OnEnable()
    {
        input.Enable();
        input.Player.Move.performed += OnMove;
        input.Player.Move.canceled += OnMove;
        input.Player.Run.started += _ => IsRunHeld = true;
        input.Player.Run.canceled += _ => IsRunHeld = false;
        input.Player.Jump.started += OnJump;
    }

    void Update()
    {
        MoveInput = input.Player.Move.ReadValue<Vector2>();
        IsRunHeld = input.Player.Run.IsPressed();
        IsJumpPressed = input.Player.Jump.WasPressedThisFrame();
    }

    void OnDisable()
    {
        input.Player.Jump.started -= OnJump;
        input.Disable();
    }

    void OnMove(InputAction.CallbackContext ctx)
    {
        Vector2 v = ctx.ReadValue<Vector2>();
        if (v.sqrMagnitude < 0.0001f) v = Vector2.zero;
        MoveInput = v;
    }
    private void OnJump(InputAction.CallbackContext _)
    {
        _jumpQueued = true;
    }

    public bool ConsumeJump()
    {
        if (!_jumpQueued) return false;
        _jumpQueued = false;
        return true;
    }
    public Vector3 GetCameraRelativeMoveDir()
    {
        if (!HasMoveInput || Camera.main == null)
            return Vector3.zero;

        Transform cam = Camera.main.transform;
        Vector3 f = cam.forward; f.y = 0; f.Normalize();
        Vector3 r = cam.right; r.y = 0; r.Normalize();

        Vector3 dir = f * MoveInput.y + r * MoveInput.x;
        return dir.sqrMagnitude > 1f ? dir.normalized : dir;
    }
}
